package modullager;

public class orderLine {
private int quantity; 
private Product p; 
private int orderlineId;
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public int getOrderlineId() {
	return orderlineId;
}
public void setOrderlineId(int orderlineId) {
	this.orderlineId = orderlineId;
}
}
