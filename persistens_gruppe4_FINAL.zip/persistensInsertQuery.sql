use dmab0920_1086245;

SET ANSI_WARNINGS off
go


--insert into Zipcodecity(zipcode, city, countrycode) values (75001, 'Dallas', 1)

--insert into Countrycode(countrycode, country) values (1, 'USA')

--insert into Customer(name, phoneno, adress, zipcode, customertype) values ('John', '12345678','Vejen 45', 9000, 'private');

--insert into PrivateCustomer(fname, lname, frieght, phoneno) values ('John', 'Testmand', 0, '12345678');

--insert into Club(name, discount, phoneno) values ('Stockholm Cowboys', 20, '99999999');

--insert into Supplier(name, adress, zipcode, countrycode, country, phoneno, email) values ('Dallas Gutterne', 'Dallas Street',  75001, 1, 'USA' ,'88888888', 'USAsupplier@supplier')

--insert into Invoice (paymentDate, amount, freight, invoiceNo) values ('20-03-2021', 100, 45, 0)

--insert into SaleOrder(date, amount, deliverystatus, deliverydate, freight, saleorderid, invoiceno, phoneno, orderlineid) values ('19-03-2021', 2,'not delivered', '22-03-2021', 0, 1, 0, '12345678', 1);

--insert into Product(producttype, calibre, material, description, type, colour, size, name, purchaseprice, salesprice, rentprice, countryOfOrigin, minStock, productid, email) values ('Clothing', null, null, null, null, 'Brown', 30, 'Texas Poncho', 50, 180, 70, 'USA', 150, 3, 'USAsupplier@supplier');

--insert into OrderLine(amountofproducts, totalpriceofproducts, productid, orderlineid, saleorderid) values(1, 180,3, 1, 1)


select * from Customer, Zipcodecity where phoneno = 12345678 and customer.zipcode = Zipcodecity.zipcode

select * from Customer

select * from PrivateCustomer

select * from Club

select * from SaleOrder

select * from Product

select * from Zipcodecity

select * from Countrycode

select * from OrderLine

select * from Supplier

select * from Invoice