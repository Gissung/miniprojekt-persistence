package uiLager;

import java.sql.SQLException;
import java.util.Scanner;
import controller.SaleOrderController;

public class UI {
	private static SaleOrderController soc;
	
	
	public static void main(String[] args) throws SQLException {
		soc = new SaleOrderController();
		display(soc);
	}
	
	static void display(SaleOrderController soc) throws SQLException{
		soc.createOrder();
		soc.addProductTOrderLine(3, 1);
		soc.findCustomer("12345678");
		soc.endSale();
	}

	

}

	



