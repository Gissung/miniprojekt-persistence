package modullager;

import java.util.ArrayList;
import java.util.List;


public class Order {
	private Customer customer;
	private int saleOrderid;
	private List<OrderLine> orderlines;
	private Invoice invoice;
	
	public Order(Customer customer, int saleOrderId) {
		this();
		this.customer = customer;
		this.saleOrderid = saleOrderId;
	}

	public Order() {
		orderlines = new ArrayList<>();
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public List<OrderLine> getOrderLine() {
		return orderlines;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public int getSaleOrderid() {
		return saleOrderid;
	}

	public void setSaleOrderid(int saleOrderid) {
		this.saleOrderid = saleOrderid;
	}

	public void addOrderLine(Product p, int quantity) {
		OrderLine ol = new OrderLine(quantity, p);
		orderlines.add(ol);
	}
	
	@Override
	public String toString() {
		return "Order [customer=" + customer + ", saleOrderid=" + saleOrderid + ", orderlines=" + orderlines
				+ ", invoice=" + invoice + "]";
	}
	
}
