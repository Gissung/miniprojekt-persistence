package modullager;

public class Invoice {
	private int invoiceNumber;
	private String paymentDate;
	private int totalPrice;
	private int freight;
	private int amount;
	
	public Invoice(int invoiceNumber, String paymentDate, int totalPrice, int freight, int amount) {
		this(invoiceNumber);
		this.paymentDate = paymentDate;
		this.totalPrice = totalPrice;
		this.freight = freight;
	}

	public Invoice(int invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public int getInvoiceNumber() {
		return invoiceNumber;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getFreight() {
		return freight;
	}

	public void setFreight(int freight) {
		this.freight = freight;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Invoice [invoiceNumber=" + invoiceNumber + ", paymentDate=" + paymentDate + ", totalPrice=" + totalPrice
				+ ", freight=" + freight + ", amount=" + amount + "]";
	}
	
	
	
}
