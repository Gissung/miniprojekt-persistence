package modullager;

import java.sql.SQLException;

public interface SaleOrderDBIF {

	void saveSale(Order order) throws SQLException;

	 
	

}
