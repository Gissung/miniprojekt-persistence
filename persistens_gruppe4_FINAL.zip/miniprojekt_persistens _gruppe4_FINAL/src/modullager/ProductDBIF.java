package modullager;

import java.sql.SQLException;

public interface ProductDBIF {

	Product findProduct(int productId) throws SQLException;
	
	
}
