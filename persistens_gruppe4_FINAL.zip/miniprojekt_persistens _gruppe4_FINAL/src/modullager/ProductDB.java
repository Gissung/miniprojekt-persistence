package modullager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductDB implements ProductDBIF{

	private static final String findProductbyIdQ = "select * from product where productid = ?";
	private PreparedStatement findProductById; 
	private int id; 
	
	
	public ProductDB() {

		try {
			findProductById = DBConnection.getInstance().getConnection().prepareStatement(findProductbyIdQ);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	 public Product findProduct(int productId) throws SQLException {
		findProductById.setInt(1, id);
		ResultSet rs = findProductById.executeQuery();
		Product p = null;
		if (rs.next()) {
			p = buildObject(rs);
		}

		return p;

	}

	private Product buildObject(ResultSet rs) throws SQLException {
		Product p = new Product(rs.getString("name"), rs.getInt("purchaseprice"), rs.getInt("salesprice"),
				rs.getInt("rentprice"), rs.getString("countryOfOrigin"), rs.getInt("productId"), rs.getInt("minStock"), rs.getString("email"));
		return p;
	}

	
	
}
