package modullager;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import modullager.Order;

public class SaleOrderDB implements SaleOrderDBIF {
	private static final String saveSaleOrderQ = "insert into SaleOrder(date, amount, freight, invoiceno, deliverystatus, deliverydate, saleorderid, phoneno, orderlineid) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private PreparedStatement saveSaleOrder;

	public SaleOrderDB() {
		try {
			saveSaleOrder = DBConnection.getInstance().getConnection().prepareStatement(saveSaleOrderQ);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void saveSale(Order order) throws SQLException {
		Invoice invoice = order.getInvoice();
		Customer customer = order.getCustomer();
		try {
			saveSaleOrder.setDate(1, Date.valueOf(LocalDate.now()));
			saveSaleOrder.setInt(2, invoice.getAmount());
			saveSaleOrder.setInt(3, invoice.getFreight());
			saveSaleOrder.setInt(4, invoice.getInvoiceNumber());
			saveSaleOrder.setString(5, "not delivered");
			saveSaleOrder.setDate(6, Date.valueOf(LocalDate.now()));
			saveSaleOrder.setInt(7, (int) System.currentTimeMillis());
			saveSaleOrder.setString(8, customer.getPhoneNo());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			saveSaleOrder.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
