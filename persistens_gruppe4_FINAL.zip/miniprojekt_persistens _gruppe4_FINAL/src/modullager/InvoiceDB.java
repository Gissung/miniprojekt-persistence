package modullager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InvoiceDB implements InvoiceDBIF {
	private static final String saveInvoiceQ = "insert into Invoice(paymentDate, amount, freight, invoiceNo) values (?, ?, ?, ?)";
	private PreparedStatement saveInvoice; 
	
	
	public InvoiceDB() {
		try {
			saveInvoice = DBConnection.getInstance().getConnection().prepareStatement(saveInvoiceQ);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Invoice saveInvoice(Invoice invoice) throws SQLException {
		try {
			saveInvoice.setString(1, invoice.getPaymentDate());
			saveInvoice.setInt(2, invoice.getAmount());
			saveInvoice.setInt(3, invoice.getFreight());
			saveInvoice.setInt(4, invoice.getInvoiceNumber());
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		try {
		saveInvoice.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	return invoice;
	
	}
	 
}
