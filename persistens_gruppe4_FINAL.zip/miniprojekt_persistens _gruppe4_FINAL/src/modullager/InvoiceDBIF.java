package modullager;

import java.sql.SQLException;


public interface InvoiceDBIF {

	Invoice saveInvoice(Invoice invoice) throws SQLException;
	
}
