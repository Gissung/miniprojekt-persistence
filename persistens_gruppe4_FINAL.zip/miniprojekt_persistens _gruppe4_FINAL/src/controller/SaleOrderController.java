package controller;

import java.sql.SQLException;


import modullager.SaleOrderDBIF;
import modullager.Customer;
import modullager.Invoice;
import modullager.InvoiceDBIF;
import modullager.Order;
import modullager.Product;

public class SaleOrderController {
	private SaleOrderDBIF soif;  
	private InvoiceDBIF invoiceIf;
	private ProductController pc;
	private CustomerController cc;
	private Order order;

	public SaleOrderController() {
		pc = new ProductController();
		cc = new CustomerController();
	}

	public Order createOrder() {
		order = new Order();
		return order;
	} 
	
	public void addProductTOrderLine(int productId, int quantity) throws SQLException {
		Product p = pc.findProductById(productId);
		order.addOrderLine(p, quantity);
	}
	
	public void findCustomer(String phoneno) throws SQLException{
		Customer c = cc.findCustomer(phoneno);
		order.setCustomer(c);
	}
	
	public Invoice endSale() throws SQLException {
		Invoice invoice = new Invoice((int)(System.currentTimeMillis()));
		invoiceIf.saveInvoice(invoice);
		order.setInvoice(invoice);
		soif.saveSale(order);
		return invoice;
	}


}
