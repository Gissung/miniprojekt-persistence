package controller;

import java.sql.SQLException;

import modullager.Customer;
import modullager.CustomerDB;
import modullager.CustomerDBIF;

public class CustomerController {
	private CustomerDBIF cdbif;
	
	public CustomerController() {
		cdbif = new CustomerDB();
	}
	
	public Customer findCustomer(String phoneno) throws SQLException {
		return cdbif.findCustomer(phoneno);
	}

}
