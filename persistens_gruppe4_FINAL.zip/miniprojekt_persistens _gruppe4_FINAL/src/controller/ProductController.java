package controller;
import modullager.Product;
import modullager.ProductDB;
import modullager.ProductDBIF;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductController {
	private ProductDBIF pdbif;
	
	public ProductController() {
		pdbif = new ProductDB();
	}
	
	public Product findProductById(int productId) throws SQLException {
			return pdbif.findProduct(productId);
	
	}

	
	
	
	
}
