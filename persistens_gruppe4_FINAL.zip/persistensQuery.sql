use dmab0920_1086245;

--drop table OrderLine
--drop table Product
--drop table SaleOrder
--drop table Invoice
--drop table Supplier
--drop table Club
--drop table PrivateCustomer
--drop table Customer
--drop table Zipcodecity
--drop table Countrycode

create table Countrycode(
	countrycode int not null,
	country varchar(100) not null,
	primary key(countrycode)
)

create table Zipcodecity(
	zipcode int not null,
	city varchar(100) not null,
	countrycode int not null,
	primary key(zipcode),
	foreign key(countrycode) references countrycode(countrycode),
)

create table Customer(
	name varchar(100) not null,
	phoneno varchar(100) not null,
	primary key(phoneno),
	zipcode int not null,
	adress varchar(100) not null,
	customertype varchar(100) not null,
	foreign key(zipcode) references Zipcodecity(zipcode),
)

create table PrivateCustomer(
	fname varchar(100) not null,
	lname varchar(100) not null,
	frieght int not null,
	phoneno varchar(100) not null,
	foreign key(phoneno) references Customer(phoneno),
) 

create table Club(
	name varchar(100) not null,
	discount int not null,
	phoneno varchar(100) not null,
	foreign key(phoneno) references Customer(phoneno),
) 

create table Supplier(
	name varchar(100) not null,
	phoneno varchar(100) not null,
	adress varchar(100) not null,
	country varchar(100) not null,
	email varchar(100) not null,
	zipcode int not null,
	countrycode int not null,
	primary key(email),
	foreign key(zipcode) references Zipcodecity(zipcode),
	foreign key(countrycode) references Countrycode(countrycode),
)

create table Invoice(
	paymentDate varchar(100) not null,
	amount int not null,
	freight int not null,
	invoiceno int not null,
	primary key(invoiceno),
)

create table SaleOrder(
	date varchar(100)  not null,
	amount int not null,
	deliverystatus varchar(100) not null,
	deliverydate varchar(100) not null,
	freight int not null,
	saleorderid int not null,
	invoiceno int not null,
	phoneno varchar(100) not null,
	orderlineid int not null,
	primary key(saleorderid),
	foreign key(phoneno) references Customer(phoneno),
	foreign key(invoiceno) references Invoice(invoiceno),
)

create table Product(
	producttype varchar(100) not null,
	calibre int,
	material varchar(100),
	description varchar(100),
	type varchar(100),
	colour varchar(100),
	size int,
	name varchar(100) not null,
	purchaseprice int not null,
	salesprice int not null,
	rentprice int not null,
	countryOfOrigin varchar(100) not null,
	minStock int not null,
	productid int not null,
	email varchar(100) not null,
	primary key(productid),
	foreign key(email) references Supplier(email),
)


create table OrderLine(
	amountofproducts int not null,
	totalpriceofproducts int not null,
	productid int not null,
	orderlineid int not null,
	saleorderid int not null,
	primary key(orderlineid),
	foreign key(productid) references Product(productid),
	foreign key(saleorderid) references SaleOrder(saleorderid),
)







