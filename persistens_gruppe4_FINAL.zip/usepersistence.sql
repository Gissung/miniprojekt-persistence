use dmab0920_1086245
create database miniprojekt_persistens
